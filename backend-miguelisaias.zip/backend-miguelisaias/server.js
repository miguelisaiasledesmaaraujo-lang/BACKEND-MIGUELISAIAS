const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

// Configuração do banco de dados
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'crud_funcionarios'
};

const db = mysql.createPool(dbConfig);

// GET: Listar funcionários
app.get('/api/funcionarios', async (req, res) => {
    try {
        const [rows] = await db.execute(
            'SELECT * FROM funcionarios ORDER BY id DESC'
        );

        res.json(rows);

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST: Cadastrar funcionário
app.post('/api/funcionarios', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;
        const valorSalario = Number(salario);

        if (!nome || !funcao || salario === undefined ||
            salario === null || salario === '' ||
            !Number.isFinite(valorSalario) || valorSalario < 0) {
            return res.status(400).json({
                error: 'Dados inválidos ou campos obrigatórios'
            });
        }

        const [result] = await db.execute(
            'INSERT INTO funcionarios (nome, funcao, salario) VALUES (?, ?, ?)',
            [nome, funcao, valorSalario]
        );

        res.json({
            success: true,
            id: result.insertId
        });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT: Atualizar funcionário
app.put('/api/funcionarios/:id', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;
        const id = Number(req.params.id);
        const valorSalario = Number(salario);

        if (!Number.isInteger(id) || id <= 0 ||
            !nome || !funcao || salario === undefined ||
            salario === null || salario === '' ||
            !Number.isFinite(valorSalario) || valorSalario < 0) {
            return res.status(400).json({
                error: 'Dados inválidos'
            });
        }

        const [result] = await db.execute(
            'UPDATE funcionarios SET nome = ?, funcao = ?, salario = ? WHERE id = ?',
            [nome, funcao, valorSalario, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                error: 'Funcionário não encontrado'
            });
        }

        res.json({ success: true });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE: Excluir funcionário
app.delete('/api/funcionarios/:id', async (req, res) => {
    try {
        const id = Number(req.params.id);

        if (!Number.isInteger(id) || id <= 0) {
            return res.status(400).json({
                error: 'ID inválido'
            });
        }

        const [result] = await db.execute(
            'DELETE FROM funcionarios WHERE id = ?',
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                error: 'Funcionário não encontrado'
            });
        }

        res.json({ success: true });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Inicialização do servidor
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
    console.log('Endpoints: /api/funcionarios');
});